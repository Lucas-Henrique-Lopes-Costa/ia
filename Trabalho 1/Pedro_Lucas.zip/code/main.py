from sklearn.datasets import load_iris

iris = load_iris()
iris